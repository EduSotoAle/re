from django.apps import AppConfig


class LibreriaConfig(AppConfig):
    name = 'libreria'
